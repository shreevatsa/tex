#include <condefs.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEUNIT("adler32.c");
USEUNIT("compress.c");
USEUNIT("crc32.c");
USEUNIT("deflate.c");
USEUNIT("gzio.c");
USEUNIT("infblock.c");
USEUNIT("infcodes.c");
USEUNIT("inffast.c");
USEUNIT("inflate.c");
USEUNIT("inftrees.c");
USEUNIT("infutil.c");
USEUNIT("trees.c");
USEUNIT("uncompr.c");
USEUNIT("zutil.c");
//---------------------------------------------------------------------------
#define Library

// To add a file to the library use the Project menu 'Add to Project'.

