/* define if you have fseek64() and ftell64() */
#undef HAVE_FSEEK64

/* define if you have mkstemp() and decl. in stdlib.h */
#undef HAVE_MKSTEMP

/* define if you have mkstemps() */
#undef HAVE_MKSTEMPS
