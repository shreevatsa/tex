/* aconf.h.  Generated automatically by configure.  */
/* xpdf/c-auto.in.  Generated automatically from configure.in by autoheader.  */

/* define if you have fseek64() and ftell64() */
/* #undef HAVE_FSEEK64 */

/* define if you have mkstemp() and decl. in stdlib.h */
#define HAVE_MKSTEMP 1

/* define if you have mkstemps() */
/* #undef HAVE_MKSTEMPS */

/* Define if you have the fseek64 function.  */
/* #undef HAVE_FSEEK64 */

/* Define if you have the ftell64 function.  */
/* #undef HAVE_FTELL64 */

/* Define if you have the mkstemps function.  */
/* #undef HAVE_MKSTEMPS */

/* Define if you have the popen function.  */
#define HAVE_POPEN 1

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */
