
EXTERN void scan_thread_id (void);


EXTERN void out_thread (int thread);
EXTERN void do_thread (pointer p, pointer parent_box, scaled x, scaled y);
EXTERN void append_thread (pointer parent_box, scaled x, scaled y);
EXTERN void end_thread (void);


