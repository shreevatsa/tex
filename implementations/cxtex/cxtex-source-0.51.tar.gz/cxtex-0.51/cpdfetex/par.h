EXTERN void normal_paragraph (void);
EXTERN small_number norm_min (int h);
EXTERN void new_graf (boolean indented);
EXTERN void indent_in_hmode (void);
EXTERN void head_for_vmode (void);
EXTERN void end_graf (void);
EXTERN void resume_after_display (void) ;
