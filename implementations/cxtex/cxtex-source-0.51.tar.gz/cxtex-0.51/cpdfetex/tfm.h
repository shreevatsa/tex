
EXTERN internal_font_number read_font_info (pointer u, str_number nom, str_number aire, scaled s);

