
/* module 1436 */
#define show_code 0
#define show_box_code 1
#define show_the_code 2
#define show_lists 3

EXTERN void show_whatever (void);
EXTERN void print_group (boolean e);
