
/* module 1021 */
#define next_break  prev_break

EXTERN void  post_line_break (boolean d);
