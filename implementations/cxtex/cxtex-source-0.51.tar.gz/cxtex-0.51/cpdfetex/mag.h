
EXTERN void prepare_mag (void);

EXTERN void mag_initialize(void);
