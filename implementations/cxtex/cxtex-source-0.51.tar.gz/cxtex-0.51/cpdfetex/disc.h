
/* module 145 */
#define disc_node 7
#define replace_count  subtype
#define pre_break  llink
#define post_break  rlink

EXTERN pointer new_disc (void);


EXTERN void append_discretionary (void);

EXTERN void build_discretionary (void);
